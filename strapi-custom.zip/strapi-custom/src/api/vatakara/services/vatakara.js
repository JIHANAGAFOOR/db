'use strict';

/**
 * vatakara service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::vatakara.vatakara');
