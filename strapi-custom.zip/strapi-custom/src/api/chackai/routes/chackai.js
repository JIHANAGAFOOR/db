'use strict';

/**
 * chackai router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::chackai.chackai');
