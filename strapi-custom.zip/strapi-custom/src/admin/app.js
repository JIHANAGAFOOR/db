// const config = {
//   auth: {},
//   head: {},
//   menu: {},
//   translations: {
//     en: {
//       "app.components.Leftmenu.navbranc.title": "ITI",
//       "app.components.LeftMenu.navbrand.title": "Dashboard",
//       "Auth.form.welcome.title": "Welcome to ITIs",
//       "app.components.GuidedTour.title": "Welcome to ITIS",
//     },
//   },
// };

// const bootstrap = (app) => {
//   console.log(app);
// };

// export default {
//   config,
//   bootstrap,
// };


// import type { StrapiApp } from "@strapi/strapi/admin"

export default {
  config: {
    tutorials: false,
    locales: [],
  },
  bootstrap() {},
  register(app) {
    const indexRoute = app.router.routes.find(({ index }) => index)
    if (!indexRoute) throw new Error("unable to find index page")
    indexRoute.lazy = async () => {
      const { Homepage } = await import("./Homepage")
      return { Component: Homepage }
    }
  },
}
