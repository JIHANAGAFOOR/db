import type { Schema, Struct } from '@strapi/strapi';

export interface AcademicsCtsProgram extends Struct.ComponentSchema {
  collectionName: 'components_academics_cts_programs';
  info: {
    description: '';
    displayName: 'CTSProgram';
  };
  attributes: {
    NCVT: Schema.Attribute.Component<'shared.program', true>;
    SCVT: Schema.Attribute.Component<'shared.program', true>;
  };
}

export interface AcademicsPmkvy extends Struct.ComponentSchema {
  collectionName: 'components_academics_pmkvies';
  info: {
    displayName: 'PMKVY';
  };
  attributes: {
    Description: Schema.Attribute.Component<'shared.description', false>;
    ProgramGuildlines: Schema.Attribute.Component<'shared.bullet-points', true>;
    Programs: Schema.Attribute.Component<'shared.bullet-points', true>;
  };
}

export interface AcademicsStt extends Struct.ComponentSchema {
  collectionName: 'components_academics_stts';
  info: {
    displayName: 'STT';
  };
  attributes: {
    Description: Schema.Attribute.Component<'shared.description', false>;
    ProgramGuildlines: Schema.Attribute.Component<'shared.bullet-points', true>;
    Programs: Schema.Attribute.Component<'shared.bullet-points', true>;
  };
}

export interface AdmissionAdmissionLink extends Struct.ComponentSchema {
  collectionName: 'components_admission_admission_links';
  info: {
    displayName: 'AdmissionLink';
  };
  attributes: {
    link: Schema.Attribute.Text;
  };
}

export interface AdmissionProspectus extends Struct.ComponentSchema {
  collectionName: 'components_admission_prospectuses';
  info: {
    displayName: 'Prospectus';
  };
  attributes: {
    Description: Schema.Attribute.Component<'shared.description', false>;
    heading: Schema.Attribute.String;
    NCVT: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    SCVT: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
  };
}

export interface AdmissionUserManual extends Struct.ComponentSchema {
  collectionName: 'components_admission_user_manuals';
  info: {
    description: '';
    displayName: 'UserManual';
  };
  attributes: {
    Description: Schema.Attribute.Component<'shared.description', false>;
    heading: Schema.Attribute.String;
    NCVT: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    SCVT: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
  };
}

export interface DownloadCirculars extends Struct.ComponentSchema {
  collectionName: 'components_download_circulars';
  info: {
    description: '';
    displayName: 'Circulars';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.data', true>;
    Description: Schema.Attribute.Component<'shared.description', true>;
  };
}

export interface DownloadForm extends Struct.ComponentSchema {
  collectionName: 'components_download_forms';
  info: {
    description: '';
    displayName: 'Form';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.form-data', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface DownloadRanklist extends Struct.ComponentSchema {
  collectionName: 'components_download_ranklists';
  info: {
    description: '';
    displayName: 'Ranklist';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.ranklist', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface FacilitiesHostel extends Struct.ComponentSchema {
  collectionName: 'components_facilities_hostels';
  info: {
    description: '';
    displayName: 'Hostel';
  };
  attributes: {
    Description: Schema.Attribute.Component<'shared.description', false>;
    Facilities: Schema.Attribute.Component<'shared.bullet-points', true>;
    Rules: Schema.Attribute.Component<'shared.bullet-points', true>;
  };
}

export interface FacilitiesIndustryTieUps extends Struct.ComponentSchema {
  collectionName: 'components_facilities_industry_tie_ups';
  info: {
    description: '';
    displayName: 'IndustryTieUps';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.industry-tie-ups', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface FacilitiesLibrary extends Struct.ComponentSchema {
  collectionName: 'components_facilities_libraries';
  info: {
    description: '';
    displayName: 'Library';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.library', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface FacilitiesOtherActivities extends Struct.ComponentSchema {
  collectionName: 'components_facilities_other_activities';
  info: {
    description: '';
    displayName: 'OtherActivities';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.other-activities', true>;
  };
}

export interface FacilitiesWomenCell extends Struct.ComponentSchema {
  collectionName: 'components_facilities_women_cells';
  info: {
    description: '';
    displayName: 'WomenCell';
  };
  attributes: {
    contact: Schema.Attribute.Component<'shared.contact', false>;
    Data: Schema.Attribute.Component<'shared.women-cell', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
    Objectives: Schema.Attribute.Component<'shared.bullet-points', true>;
  };
}

export interface HomeHome extends Struct.ComponentSchema {
  collectionName: 'components_home_homes';
  info: {
    description: '';
    displayName: 'Home';
  };
  attributes: {
    Address: Schema.Attribute.Component<'shared.address', false>;
    Description: Schema.Attribute.Component<'shared.iti-description', false>;
    Events: Schema.Attribute.Component<'shared.event', false>;
    Gallery: Schema.Attribute.Component<'shared.gallery', true>;
    Images: Schema.Attribute.Media<
      'images' | 'files' | 'videos' | 'audios',
      true
    >;
    iti_email: Schema.Attribute.Email;
    iti_name: Schema.Attribute.String & Schema.Attribute.Required;
    iti_url: Schema.Attribute.String;
    Map: Schema.Attribute.Component<'shared.map', false>;
    mis_code: Schema.Attribute.String;
    Mission: Schema.Attribute.Component<'shared.mission', false>;
    News: Schema.Attribute.Component<'shared.news', true>;
    phone_number: Schema.Attribute.String;
    Trades: Schema.Attribute.Component<'shared.trades', true>;
    Useful_Links: Schema.Attribute.Component<'shared.useful-links', true>;
    Vision: Schema.Attribute.Component<'shared.vision', false>;
  };
}

export interface InstituteAwards extends Struct.ComponentSchema {
  collectionName: 'components_institute_awards';
  info: {
    displayName: 'Awards';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.awards-list', true>;
    Description: Schema.Attribute.Component<'shared.description', true>;
  };
}

export interface InstituteCertifications extends Struct.ComponentSchema {
  collectionName: 'components_institute_certifications';
  info: {
    displayName: 'Certifications';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.certfication-list', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface InstituteGrading extends Struct.ComponentSchema {
  collectionName: 'components_institute_gradings';
  info: {
    displayName: 'Grading';
  };
  attributes: {
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface InstituteImc extends Struct.ComponentSchema {
  collectionName: 'components_institute_imcs';
  info: {
    description: '';
    displayName: 'IMC';
  };
  attributes: {
    Announcements: Schema.Attribute.Component<'shared.announcements', true>;
    Data: Schema.Attribute.Component<'shared.imc-list', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface InstituteInfrastructure extends Struct.ComponentSchema {
  collectionName: 'components_institute_infrastructures';
  info: {
    displayName: 'Infrastructure';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.infrastrture-list', true>;
    Description: Schema.Attribute.Component<'shared.description', true>;
  };
}

export interface InstituteInstitute extends Struct.ComponentSchema {
  collectionName: 'components_institute_institutes';
  info: {
    description: '';
    displayName: 'Principle_desk';
  };
  attributes: {
    Principle: Schema.Attribute.Component<'shared.principle', false>;
    VicePrinciple: Schema.Attribute.Component<'shared.principle', false>;
  };
}

export interface InstitutePta extends Struct.ComponentSchema {
  collectionName: 'components_institute_ptas';
  info: {
    displayName: 'PTA';
  };
  attributes: {
    Announcements: Schema.Attribute.Component<'shared.announcements', true>;
    Data: Schema.Attribute.Component<'shared.pta-list', true>;
    Description: Schema.Attribute.Component<'shared.description', true>;
  };
}

export interface NotificationsQuotation extends Struct.ComponentSchema {
  collectionName: 'components_notifications_quotations';
  info: {
    description: '';
    displayName: 'Quotation';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.quotation', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface NotificationsTenders extends Struct.ComponentSchema {
  collectionName: 'components_notifications_tenders';
  info: {
    description: '';
    displayName: 'Tenders';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.notifications', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface PlacementEvents extends Struct.ComponentSchema {
  collectionName: 'components_placement_events';
  info: {
    displayName: 'Events';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.plcement-events', true>;
  };
}

export interface PlacementIndustrialExpereince extends Struct.ComponentSchema {
  collectionName: 'components_placement_industrial_expereinces';
  info: {
    displayName: 'IndustrialExpereince';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.industrial-experience', true>;
  };
}

export interface PlacementNotification extends Struct.ComponentSchema {
  collectionName: 'components_placement_notifications';
  info: {
    description: '';
    displayName: 'Notification';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.placement-notification', true>;
  };
}

export interface PlacementResults extends Struct.ComponentSchema {
  collectionName: 'components_placement_results';
  info: {
    displayName: 'Results';
  };
  attributes: {
    company_name: Schema.Attribute.Component<'shared.placed-company', true>;
    Data: Schema.Attribute.Component<'shared.placement-result', true>;
  };
}

export interface SharedALumniList extends Struct.ComponentSchema {
  collectionName: 'components_shared_a_lumni_lists';
  info: {
    displayName: 'ALumniList';
  };
  attributes: {
    batch: Schema.Attribute.String;
    Designation: Schema.Attribute.String;
    industry: Schema.Attribute.String;
    mobile: Schema.Attribute.Integer;
    Name: Schema.Attribute.String;
  };
}

export interface SharedAchievementsList extends Struct.ComponentSchema {
  collectionName: 'components_shared_achievements_lists';
  info: {
    displayName: 'AchievementsList';
  };
  attributes: {
    description: Schema.Attribute.Text;
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    year: Schema.Attribute.Date;
  };
}

export interface SharedActivities extends Struct.ComponentSchema {
  collectionName: 'components_shared_activities';
  info: {
    displayName: 'Activities';
  };
  attributes: {
    description: Schema.Attribute.Text;
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    year: Schema.Attribute.Date;
  };
}

export interface SharedAddress extends Struct.ComponentSchema {
  collectionName: 'components_shared_addresses';
  info: {
    displayName: 'address';
  };
  attributes: {
    district: Schema.Attribute.Component<'shared.district', false>;
    location: Schema.Attribute.Component<'shared.location', false>;
    pin: Schema.Attribute.Integer;
  };
}

export interface SharedAnnouncements extends Struct.ComponentSchema {
  collectionName: 'components_shared_announcements';
  info: {
    displayName: 'Announcements';
  };
  attributes: {
    en: Schema.Attribute.Text;
    ml: Schema.Attribute.Text;
  };
}

export interface SharedAuctions extends Struct.ComponentSchema {
  collectionName: 'components_shared_auctions';
  info: {
    description: '';
    displayName: 'Auctions';
  };
  attributes: {
    auction_status: Schema.Attribute.Enumeration<
      ['upcoming', 'completed', 'cancelled']
    >;
    date: Schema.Attribute.Date;
    Description: Schema.Attribute.Component<'shared.description', false>;
    location: Schema.Attribute.String;
    reference_number: Schema.Attribute.String;
    starting_bid: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface SharedAwardsList extends Struct.ComponentSchema {
  collectionName: 'components_shared_awards_lists';
  info: {
    displayName: 'AwardsList';
  };
  attributes: {
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    year: Schema.Attribute.Date;
  };
}

export interface SharedBulletPoints extends Struct.ComponentSchema {
  collectionName: 'components_shared_bullet_points';
  info: {
    displayName: 'BulletPoints';
  };
  attributes: {
    points: Schema.Attribute.Text;
  };
}

export interface SharedCertficationList extends Struct.ComponentSchema {
  collectionName: 'components_shared_certfication_lists';
  info: {
    displayName: 'CertficationList';
  };
  attributes: {
    certfications: Schema.Attribute.Text;
  };
}

export interface SharedContact extends Struct.ComponentSchema {
  collectionName: 'components_shared_contacts';
  info: {
    displayName: 'contact';
  };
  attributes: {
    email: Schema.Attribute.Email;
    helpline_number: Schema.Attribute.Integer;
    women_cell_office: Schema.Attribute.String;
  };
}

export interface SharedData extends Struct.ComponentSchema {
  collectionName: 'components_shared_data';
  info: {
    description: '';
    displayName: 'Circulars';
  };
  attributes: {
    Category: Schema.Attribute.String;
    Date: Schema.Attribute.Date;
    pdf: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
  };
}

export interface SharedDescription extends Struct.ComponentSchema {
  collectionName: 'components_shared_descriptions';
  info: {
    displayName: 'Description';
  };
  attributes: {
    en: Schema.Attribute.Text;
    ml: Schema.Attribute.Text;
  };
}

export interface SharedDistrict extends Struct.ComponentSchema {
  collectionName: 'components_shared_districts';
  info: {
    displayName: 'district';
  };
  attributes: {
    en: Schema.Attribute.String;
    ml: Schema.Attribute.String;
  };
}

export interface SharedEducation extends Struct.ComponentSchema {
  collectionName: 'components_shared_educations';
  info: {
    displayName: 'Education';
  };
  attributes: {};
}

export interface SharedEvent extends Struct.ComponentSchema {
  collectionName: 'components_shared_events';
  info: {
    displayName: 'event';
  };
  attributes: {
    event_content: Schema.Attribute.Component<'shared.event-content', true>;
  };
}

export interface SharedEventContent extends Struct.ComponentSchema {
  collectionName: 'components_shared_event_contents';
  info: {
    displayName: 'event_content';
  };
  attributes: {
    en: Schema.Attribute.Text;
    ml: Schema.Attribute.String;
    youtube_link: Schema.Attribute.String;
  };
}

export interface SharedFormData extends Struct.ComponentSchema {
  collectionName: 'components_shared_form_data';
  info: {
    description: '';
    displayName: 'FormData';
  };
  attributes: {
    pdf: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
  };
}

export interface SharedGallery extends Struct.ComponentSchema {
  collectionName: 'components_shared_galleries';
  info: {
    description: '';
    displayName: 'gallery';
  };
  attributes: {
    gallery_content: Schema.Attribute.Component<'shared.gallery-list', true>;
  };
}

export interface SharedGalleryList extends Struct.ComponentSchema {
  collectionName: 'components_shared_gallery_lists';
  info: {
    displayName: 'gallery_list';
  };
  attributes: {
    en: Schema.Attribute.Text;
    gallery_image: Schema.Attribute.Media<
      'images' | 'files' | 'videos' | 'audios',
      true
    >;
    ml: Schema.Attribute.Text;
  };
}

export interface SharedHostel extends Struct.ComponentSchema {
  collectionName: 'components_shared_hostels';
  info: {
    description: '';
    displayName: 'Hostel';
  };
  attributes: {
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface SharedImcList extends Struct.ComponentSchema {
  collectionName: 'components_shared_imc_lists';
  info: {
    displayName: 'IMCList';
  };
  attributes: {
    designation: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    name: Schema.Attribute.String;
  };
}

export interface SharedIndustrialExperience extends Struct.ComponentSchema {
  collectionName: 'components_shared_industrial_experiences';
  info: {
    displayName: 'IndustrialExperience';
  };
  attributes: {
    company_name: Schema.Attribute.String;
    Designation: Schema.Attribute.String;
    experience: Schema.Attribute.Text;
    Name: Schema.Attribute.String;
  };
}

export interface SharedIndustryTieUps extends Struct.ComponentSchema {
  collectionName: 'components_shared_industry_tie_ups';
  info: {
    displayName: 'industryTieUps';
  };
  attributes: {
    description: Schema.Attribute.Text;
    Expertise: Schema.Attribute.String;
    name: Schema.Attribute.String;
    programs: Schema.Attribute.String;
  };
}

export interface SharedInfrastrtureList extends Struct.ComponentSchema {
  collectionName: 'components_shared_infrastrture_lists';
  info: {
    displayName: 'InfrastrtureList';
  };
  attributes: {
    description: Schema.Attribute.Text;
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
  };
}

export interface SharedItiDescription extends Struct.ComponentSchema {
  collectionName: 'components_shared_iti_descriptions';
  info: {
    displayName: 'iti_description';
  };
  attributes: {
    en: Schema.Attribute.Text;
    ml: Schema.Attribute.Text & Schema.Attribute.Required;
  };
}

export interface SharedLibrary extends Struct.ComponentSchema {
  collectionName: 'components_shared_libraries';
  info: {
    description: '';
    displayName: 'Library';
  };
  attributes: {
    book_name: Schema.Attribute.String;
    category: Schema.Attribute.String;
    stock: Schema.Attribute.String;
    trade_name: Schema.Attribute.String;
    year: Schema.Attribute.String;
  };
}

export interface SharedLocation extends Struct.ComponentSchema {
  collectionName: 'components_shared_locations';
  info: {
    displayName: 'location';
  };
  attributes: {
    en: Schema.Attribute.String;
    ml: Schema.Attribute.String;
  };
}

export interface SharedMap extends Struct.ComponentSchema {
  collectionName: 'components_shared_maps';
  info: {
    displayName: 'map';
  };
  attributes: {
    latitude: Schema.Attribute.Decimal;
    longitude: Schema.Attribute.Decimal;
  };
}

export interface SharedMembers extends Struct.ComponentSchema {
  collectionName: 'components_shared_members';
  info: {
    displayName: 'Members';
  };
  attributes: {
    Designation: Schema.Attribute.String;
    Image: Schema.Attribute.Media<
      'images' | 'files' | 'videos' | 'audios',
      true
    >;
    Name: Schema.Attribute.String;
  };
}

export interface SharedMission extends Struct.ComponentSchema {
  collectionName: 'components_shared_missions';
  info: {
    displayName: 'mission';
  };
  attributes: {
    en: Schema.Attribute.Text;
    ml: Schema.Attribute.Text;
  };
}

export interface SharedNews extends Struct.ComponentSchema {
  collectionName: 'components_shared_news';
  info: {
    description: '';
    displayName: 'news';
  };
  attributes: {
    news_content: Schema.Attribute.Component<'shared.news-content', false>;
    news_heading: Schema.Attribute.Component<'shared.news-heading', false>;
  };
}

export interface SharedNewsContent extends Struct.ComponentSchema {
  collectionName: 'components_shared_news_contents';
  info: {
    displayName: 'news_content';
  };
  attributes: {
    en: Schema.Attribute.Text;
    ml: Schema.Attribute.Text;
  };
}

export interface SharedNewsHeading extends Struct.ComponentSchema {
  collectionName: 'components_shared_news_headings';
  info: {
    displayName: 'news_heading';
  };
  attributes: {
    en: Schema.Attribute.String;
    ml: Schema.Attribute.String;
  };
}

export interface SharedNotifications extends Struct.ComponentSchema {
  collectionName: 'components_shared_notifications';
  info: {
    description: '';
    displayName: 'Notifications';
  };
  attributes: {
    date: Schema.Attribute.Date;
    department: Schema.Attribute.String;
    pdf: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    reference_number: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface SharedNssActivities extends Struct.ComponentSchema {
  collectionName: 'components_shared_nss_activities';
  info: {
    displayName: 'NSSActivities';
  };
  attributes: {
    description: Schema.Attribute.Text;
    heading: Schema.Attribute.String;
    image: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
  };
}

export interface SharedOtherActivities extends Struct.ComponentSchema {
  collectionName: 'components_shared_other_activities';
  info: {
    description: '';
    displayName: 'OtherActivities';
  };
  attributes: {
    coordinator: Schema.Attribute.String;
    description: Schema.Attribute.Text;
    mobile: Schema.Attribute.Integer;
    name: Schema.Attribute.String;
  };
}

export interface SharedPlacedCompany extends Struct.ComponentSchema {
  collectionName: 'components_shared_placed_companies';
  info: {
    displayName: 'PlacedCompany';
  };
  attributes: {
    name: Schema.Attribute.String;
  };
}

export interface SharedPlacementNotification extends Struct.ComponentSchema {
  collectionName: 'components_shared_placement_notifications';
  info: {
    description: '';
    displayName: 'PlacementNotification';
  };
  attributes: {
    company_name: Schema.Attribute.String;
    description: Schema.Attribute.Text;
    eligibility: Schema.Attribute.Text;
    time: Schema.Attribute.Time;
    venue: Schema.Attribute.String;
  };
}

export interface SharedPlacementResult extends Struct.ComponentSchema {
  collectionName: 'components_shared_placement_results';
  info: {
    displayName: 'PlacementResult';
  };
  attributes: {
    avarage_package: Schema.Attribute.Integer;
    department: Schema.Attribute.String;
    highest_package: Schema.Attribute.Integer;
    placed: Schema.Attribute.Integer;
    total_students: Schema.Attribute.Integer;
    year: Schema.Attribute.Date;
  };
}

export interface SharedPlcementEvents extends Struct.ComponentSchema {
  collectionName: 'components_shared_plcement_events';
  info: {
    displayName: 'PlcementEvents';
  };
  attributes: {
    date: Schema.Attribute.Date;
    description: Schema.Attribute.Text;
    heading: Schema.Attribute.String;
    venue: Schema.Attribute.String;
  };
}

export interface SharedPrinciple extends Struct.ComponentSchema {
  collectionName: 'components_shared_principles';
  info: {
    description: '';
    displayName: 'Principle';
  };
  attributes: {
    active: Schema.Attribute.Boolean;
    email: Schema.Attribute.Email;
    message: Schema.Attribute.Text;
    name: Schema.Attribute.String;
    office_phone: Schema.Attribute.String;
    phone: Schema.Attribute.Integer;
  };
}

export interface SharedProgram extends Struct.ComponentSchema {
  collectionName: 'components_shared_programs';
  info: {
    displayName: 'Program';
  };
  attributes: {
    affiliation_date: Schema.Attribute.Date;
    no_of_units: Schema.Attribute.Integer;
    seating_capacity_per_unit: Schema.Attribute.Integer;
    total_seating_capacity: Schema.Attribute.Integer;
    trade: Schema.Attribute.String;
  };
}

export interface SharedPtaList extends Struct.ComponentSchema {
  collectionName: 'components_shared_pta_lists';
  info: {
    displayName: 'PTAList';
  };
  attributes: {
    designation: Schema.Attribute.String;
    mobile: Schema.Attribute.Integer;
    name: Schema.Attribute.String;
  };
}

export interface SharedQuotation extends Struct.ComponentSchema {
  collectionName: 'components_shared_quotations';
  info: {
    description: '';
    displayName: 'Quotation';
  };
  attributes: {
    date: Schema.Attribute.Date;
    department: Schema.Attribute.String;
    pdf: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    reference_number: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface SharedRanklist extends Struct.ComponentSchema {
  collectionName: 'components_shared_ranklists';
  info: {
    description: '';
    displayName: 'Ranklist';
  };
  attributes: {
    Date: Schema.Attribute.Date;
    pdf: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios', true>;
  };
}

export interface SharedTable extends Struct.ComponentSchema {
  collectionName: 'components_shared_tables';
  info: {
    description: '';
    displayName: 'Table';
  };
  attributes: {
    TableData: Schema.Attribute.Component<'shared.table-data', true>;
  };
}

export interface SharedTableData extends Struct.ComponentSchema {
  collectionName: 'components_shared_table_data';
  info: {
    displayName: 'TableData';
  };
  attributes: {
    description: Schema.Attribute.String;
    pdf: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
  };
}

export interface SharedTradeList extends Struct.ComponentSchema {
  collectionName: 'components_shared_trade_lists';
  info: {
    displayName: 'trade_list';
  };
  attributes: {
    en: Schema.Attribute.String;
    ml: Schema.Attribute.String;
  };
}

export interface SharedTradeName extends Struct.ComponentSchema {
  collectionName: 'components_shared_trade_names';
  info: {
    displayName: 'trade_name';
  };
  attributes: {
    en: Schema.Attribute.String;
    ml: Schema.Attribute.String;
  };
}

export interface SharedTrades extends Struct.ComponentSchema {
  collectionName: 'components_shared_trades';
  info: {
    displayName: 'trades';
  };
  attributes: {
    trade_list: Schema.Attribute.Component<'shared.trade-list', true>;
    trade_name: Schema.Attribute.Component<'shared.trade-name', false>;
  };
}

export interface SharedTrainneesList extends Struct.ComponentSchema {
  collectionName: 'components_shared_trainnees_lists';
  info: {
    displayName: 'TrainneesList';
  };
  attributes: {
    no_of_units: Schema.Attribute.String;
    pdf: Schema.Attribute.Media<'images' | 'files' | 'videos' | 'audios'>;
    trade: Schema.Attribute.String;
  };
}

export interface SharedTrainnesCouncilList extends Struct.ComponentSchema {
  collectionName: 'components_shared_trainnes_council_lists';
  info: {
    displayName: 'TrainnesCouncilList';
  };
  attributes: {
    Designation: Schema.Attribute.String;
    Name: Schema.Attribute.String;
    trade: Schema.Attribute.String;
  };
}

export interface SharedUsefulLinks extends Struct.ComponentSchema {
  collectionName: 'components_shared_useful_links';
  info: {
    displayName: 'useful_links';
  };
  attributes: {
    url: Schema.Attribute.String;
  };
}

export interface SharedVision extends Struct.ComponentSchema {
  collectionName: 'components_shared_visions';
  info: {
    displayName: 'vision';
  };
  attributes: {
    en: Schema.Attribute.Text;
    ml: Schema.Attribute.Text;
  };
}

export interface SharedWomenCell extends Struct.ComponentSchema {
  collectionName: 'components_shared_women_cells';
  info: {
    displayName: 'WomenCell';
  };
  attributes: {
    designation: Schema.Attribute.String;
    email: Schema.Attribute.Email;
    Mobile: Schema.Attribute.Integer;
    name: Schema.Attribute.String;
    trade: Schema.Attribute.String;
  };
}

export interface TraineesAchievements extends Struct.ComponentSchema {
  collectionName: 'components_trainees_achievements';
  info: {
    displayName: 'Achievements';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.achievements-list', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface TraineesActivities extends Struct.ComponentSchema {
  collectionName: 'components_trainees_activities';
  info: {
    displayName: 'Activities';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.activities', true>;
    Description: Schema.Attribute.Component<'shared.description', true>;
  };
}

export interface TraineesAlumni extends Struct.ComponentSchema {
  collectionName: 'components_trainees_alumni';
  info: {
    description: '';
    displayName: 'Alumni';
  };
  attributes: {
    Announcements: Schema.Attribute.Component<'shared.announcements', true>;
    Data: Schema.Attribute.Component<'shared.a-lumni-list', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface TraineesNss extends Struct.ComponentSchema {
  collectionName: 'components_trainees_nsses';
  info: {
    displayName: 'NSS';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.nss-activities', true>;
    Description: Schema.Attribute.Component<'shared.description', true>;
  };
}

export interface TraineesResults extends Struct.ComponentSchema {
  collectionName: 'components_trainees_results';
  info: {
    displayName: 'Results';
  };
  attributes: {
    Description: Schema.Attribute.Component<'shared.description', false>;
    result_link: Schema.Attribute.String;
  };
}

export interface TraineesTraineesCouncil extends Struct.ComponentSchema {
  collectionName: 'components_trainees_trainees_councils';
  info: {
    displayName: 'Trainees_Council';
  };
  attributes: {
    Announcements: Schema.Attribute.Component<'shared.announcements', true>;
    Data: Schema.Attribute.Component<'shared.trainnes-council-list', true>;
    Description: Schema.Attribute.Component<'shared.description', false>;
  };
}

export interface TraineesTraineesList extends Struct.ComponentSchema {
  collectionName: 'components_trainees_trainees_lists';
  info: {
    description: '';
    displayName: 'TraineesList';
  };
  attributes: {
    Data: Schema.Attribute.Component<'shared.trainnees-list', true>;
    Description: Schema.Attribute.Component<'shared.description', true>;
  };
}

declare module '@strapi/strapi' {
  export module Public {
    export interface ComponentSchemas {
      'academics.cts-program': AcademicsCtsProgram;
      'academics.pmkvy': AcademicsPmkvy;
      'academics.stt': AcademicsStt;
      'admission.admission-link': AdmissionAdmissionLink;
      'admission.prospectus': AdmissionProspectus;
      'admission.user-manual': AdmissionUserManual;
      'download.circulars': DownloadCirculars;
      'download.form': DownloadForm;
      'download.ranklist': DownloadRanklist;
      'facilities.hostel': FacilitiesHostel;
      'facilities.industry-tie-ups': FacilitiesIndustryTieUps;
      'facilities.library': FacilitiesLibrary;
      'facilities.other-activities': FacilitiesOtherActivities;
      'facilities.women-cell': FacilitiesWomenCell;
      'home.home': HomeHome;
      'institute.awards': InstituteAwards;
      'institute.certifications': InstituteCertifications;
      'institute.grading': InstituteGrading;
      'institute.imc': InstituteImc;
      'institute.infrastructure': InstituteInfrastructure;
      'institute.institute': InstituteInstitute;
      'institute.pta': InstitutePta;
      'notifications.quotation': NotificationsQuotation;
      'notifications.tenders': NotificationsTenders;
      'placement.events': PlacementEvents;
      'placement.industrial-expereince': PlacementIndustrialExpereince;
      'placement.notification': PlacementNotification;
      'placement.results': PlacementResults;
      'shared.a-lumni-list': SharedALumniList;
      'shared.achievements-list': SharedAchievementsList;
      'shared.activities': SharedActivities;
      'shared.address': SharedAddress;
      'shared.announcements': SharedAnnouncements;
      'shared.auctions': SharedAuctions;
      'shared.awards-list': SharedAwardsList;
      'shared.bullet-points': SharedBulletPoints;
      'shared.certfication-list': SharedCertficationList;
      'shared.contact': SharedContact;
      'shared.data': SharedData;
      'shared.description': SharedDescription;
      'shared.district': SharedDistrict;
      'shared.education': SharedEducation;
      'shared.event': SharedEvent;
      'shared.event-content': SharedEventContent;
      'shared.form-data': SharedFormData;
      'shared.gallery': SharedGallery;
      'shared.gallery-list': SharedGalleryList;
      'shared.hostel': SharedHostel;
      'shared.imc-list': SharedImcList;
      'shared.industrial-experience': SharedIndustrialExperience;
      'shared.industry-tie-ups': SharedIndustryTieUps;
      'shared.infrastrture-list': SharedInfrastrtureList;
      'shared.iti-description': SharedItiDescription;
      'shared.library': SharedLibrary;
      'shared.location': SharedLocation;
      'shared.map': SharedMap;
      'shared.members': SharedMembers;
      'shared.mission': SharedMission;
      'shared.news': SharedNews;
      'shared.news-content': SharedNewsContent;
      'shared.news-heading': SharedNewsHeading;
      'shared.notifications': SharedNotifications;
      'shared.nss-activities': SharedNssActivities;
      'shared.other-activities': SharedOtherActivities;
      'shared.placed-company': SharedPlacedCompany;
      'shared.placement-notification': SharedPlacementNotification;
      'shared.placement-result': SharedPlacementResult;
      'shared.plcement-events': SharedPlcementEvents;
      'shared.principle': SharedPrinciple;
      'shared.program': SharedProgram;
      'shared.pta-list': SharedPtaList;
      'shared.quotation': SharedQuotation;
      'shared.ranklist': SharedRanklist;
      'shared.table': SharedTable;
      'shared.table-data': SharedTableData;
      'shared.trade-list': SharedTradeList;
      'shared.trade-name': SharedTradeName;
      'shared.trades': SharedTrades;
      'shared.trainnees-list': SharedTrainneesList;
      'shared.trainnes-council-list': SharedTrainnesCouncilList;
      'shared.useful-links': SharedUsefulLinks;
      'shared.vision': SharedVision;
      'shared.women-cell': SharedWomenCell;
      'trainees.achievements': TraineesAchievements;
      'trainees.activities': TraineesActivities;
      'trainees.alumni': TraineesAlumni;
      'trainees.nss': TraineesNss;
      'trainees.results': TraineesResults;
      'trainees.trainees-council': TraineesTraineesCouncil;
      'trainees.trainees-list': TraineesTraineesList;
    }
  }
}
